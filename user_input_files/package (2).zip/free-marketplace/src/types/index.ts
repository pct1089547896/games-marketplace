export interface Game {
  id: string;
  title: string;
  description: string;
  download_link: string;
  category: string;
  screenshots: string[];
  featured: boolean;
  view_count: number;
  download_count: number;
  platform: string[];
  tags: string[];
  current_version: string;
  system_requirements: Record<string, any>;
  average_rating: number;
  total_ratings: number;
  content_status: 'stable' | 'beta' | 'development';
  is_verified: boolean;
  uploader_id: string | null;
  created_at: string;
  updated_at: string;
  gallery_layout?: string;
  gallery_theme?: string;
}

export interface Program {
  id: string;
  title: string;
  description: string;
  download_link: string;
  category: string;
  screenshots: string[];
  featured: boolean;
  view_count: number;
  download_count: number;
  platform: string[];
  tags: string[];
  current_version: string;
  system_requirements: Record<string, any>;
  average_rating: number;
  total_ratings: number;
  content_status: 'stable' | 'beta' | 'development';
  is_verified: boolean;
  uploader_id: string | null;
  created_at: string;
  updated_at: string;
  gallery_layout?: string;
  gallery_theme?: string;
}

export interface ContentRating {
  id: string;
  user_id: string;
  content_id: string;
  content_type: 'game' | 'program';
  rating: number;
  review_text: string | null;
  is_approved: boolean;
  helpfulness_count: number;
  created_at: string;
  updated_at: string;
  user_profile?: UserProfile;
}

export interface UserFavorite {
  id: string;
  user_id: string;
  content_id: string;
  content_type: 'game' | 'program';
  added_at: string;
}

export interface FeaturedCollection {
  id: string;
  name: string;
  description: string;
  content_items: any[];
  collection_type: 'game' | 'program' | 'mixed';
  is_active: boolean;
  display_order: number;
  created_at: string;
  updated_at: string;
}

export interface BlogPost {
  id: string;
  title: string;
  content: string;
  author: string;
  publish_date: string;
  featured_image: string;
  is_published: boolean;
  created_at: string;
  updated_at: string;
  gallery_layout?: string;
  gallery_theme?: string;
}

export interface UserProfile {
  id: string;
  email: string;
  display_name: string;
  avatar_url: string | null;
  post_count: number;
  created_at: string;
  last_active: string;
}

export interface UserAchievement {
  id: string;
  user_id: string;
  badge_type: 'top_contributor' | 'early_adopter' | 'game_reviewer' | 'downloader' | 'community_helper';
  earned_at: string;
}

export interface DownloadTracking {
  id: string;
  user_id: string | null;
  content_id: string;
  content_type: 'game' | 'program';
  ip_address: string;
  downloaded_at: string;
}

export interface VersionHistory {
  id: string;
  content_id: string;
  content_type: 'game' | 'program';
  version: string;
  changelog: string;
  released_at: string;
}

export interface ContentReport {
  id: string;
  content_id: string;
  content_type: 'game' | 'program';
  reporter_id: string;
  reason: string;
  description: string;
  status: 'pending' | 'reviewed' | 'resolved' | 'dismissed';
  created_at: string;
  updated_at: string;
}

export interface ReviewHelpfulness {
  id: string;
  review_id: string;
  user_id: string;
  is_helpful: boolean;
  created_at: string;
}

export interface ForumCategory {
  id: string;
  name: string;
  description: string;
  slug: string;
  order_index: number;
  thread_count: number;
  created_at: string;
}

export interface ForumThread {
  id: string;
  category_id: string;
  title: string;
  content: string;
  author_id: string;
  view_count: number;
  reply_count: number;
  pinned: boolean;
  locked: boolean;
  created_at: string;
  updated_at: string;
}

export interface ForumReply {
  id: string;
  thread_id: string;
  parent_reply_id: string | null;
  content: string;
  author_id: string;
  is_edited: boolean;
  created_at: string;
  updated_at: string;
}
